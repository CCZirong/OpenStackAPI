#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from openstackclient.tests.functional import base


class BaseImageTests(base.TestCase):
    """Functional tests for Image commands"""

    @classmethod
    def setUpClass(cls):
        super(BaseImageTests, cls).setUpClass()
        # TODO(dtroyer): maybe do image API discovery here to determine
        #                what is available, it isn't in the service catalog
        cls.haz_v1_api = False
